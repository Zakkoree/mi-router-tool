#!/bin/sh
# /data/mi-toolkit/core/plugin_mgr.sh

# 同步所有配置好的应用源
sync_store_index() {
    local src_url="https://raw.githubusercontent.com/Zakkoree/mi-router-tool/HEAD/pkgs/apps.json"
    echo -e " 🔄 正在更新应用商店索引..."
    local final_url="${MIRROR}${src_url}"
#    local sources="$(mikit_db get "sources")"
#    sources="$src_url $sources"
#    for source in sources; do
#        local url="$(gh_to_raw "$source")"
#        case "$url" in
#            *raw.githubusercontent.com*)
#                url="${MIRROR}${url}"
#                ;;
#            *) : ;;
#        esac
#
#
#    done
    echo "$final_url"
#    echo -ne "   - 正在拉取源 [${C_YELLOW}${src_id}${C_RESET}] ... "

    rm -f "$MIKIT_DIR/data/store/*"

    curl -sSL --connect-timeout 5 -m 10 "$final_url" -o "$MIKIT_TMP/apps.json"
    if [ $? -eq 0 ] && [ -s "$MIKIT_TMP/apps.json" ]; then
        local source_id="$(get_jsonfile_val "$MIKIT_TMP/apps.json" "source_id" 2>/dev/null)"
        mkdir -p "$MIKIT_DIR/data/store"
        mv "$MIKIT_TMP/apps.json" "$MIKIT_DIR/data/store/source_id.json"
        echo -e "\n ✅ 更新成功"
    else
        echo -e "\n ❌ 更新失败"
    fi
}

# 说明: 校验解压后的临时应用目录合法性
# 参数 $1: 临时解压路径 (/tmp/xxx)
# 返回: 0-通过, 1-校验失败
check_app_package() {
    local tmp_dir="$1"

    if [ ! -d "$tmp_dir" ]; then
        echo -e "\n ❌ 错误: 校验目录不存在！"
        return 1
    fi

    local manifest="$tmp_dir/manifest.json"
    local init_script="$tmp_dir/init"
    local menu_script="$tmp_dir/menu"
    # 1. 结构检查
    if [ ! -f "$manifest" ]; then
        echo -e "\n ❌ 安装失败: 压缩包内缺少元数据文件 manifest.json！"
        return 1
    fi

    if [ ! -f "$init_script" ]; then
        echo -e "\n ❌ 安装失败: 压缩包内缺少启动控制脚本 (init)！"
        return 1
    fi

    if [ ! -f "$menu_script" ]; then
        echo -e "\n ❌ 安装失败: 压缩包内缺少启动控制脚本 (menu)！"
        return 1
    fi

    # 2. 读取元信息
    CHK_ID="$(get_jsonfile_val "$manifest" "id")"
    CHK_NAME="$(get_jsonfile_val "$manifest" "name")"
    CHK_VER="$(get_jsonfile_val "$manifest" "version")"
    CHK_ARCH="$(get_jsonfile_val "$manifest" "arch")"

    if [ -z "$CHK_ID" ] || [ -z "$CHK_NAME" ] || [ -z "$CHK_VER" ]; then
        echo -e "\n ❌ 安装失败: manifest.json 中 id, name 或 version 字段缺失！"
        return 1
    fi


    ! check_valid_conf_name "$CHK_ID" "id" && return 1

    # 3. 架构兼容性检测
    if [ -n "$CHK_ARCH" ] && [ "$CHK_ARCH" != "all" ]; then
        if ! echo "$CHK_ARCH" | grep -qw "$SYSTEM_ARCH"; then
            echo " ⚠️ 架构不匹配警告: 插件支持 [${CHK_ARCH}]，但当前架构为 [${sys_arch}]！"
            printf "是否仍要强行安装？(y/N): "
            read force_install
            if [ "$force_install" != "y" ] && [ "$force_install" != "Y" ]; then
                echo -e "\n ❌ 已取消安装。"
                return 1
            fi
        fi
    fi

    return 0
}

# 说明: 渲染应用详情信息界面，并提示用户安装/重装
show_store_app_detail() {
    local app_id="$1"
    local app_name="$2"
    local app_ver="$3"
    local app_desc="$4"
    local app_url="$5"
    local app_author="$6"
    local app_arch="$7"
    local app_status="$8" # installed uninstalled upgradable
    local app_local_v="$9"

    clear
    main_line
    print_center "➕ ${C_BOLD}应用详情信息${C_RESET} ${C_DIM}($source_id)${C_RESET}" 8
    sub_line
    if [ "$app_status" = "upgradable" ]; then
        local ver_str="${C_YELLOW}(v${app_local_v} -> v${app_ver})${C_RESET}"
    else
        local ver_str="${C_DIM}(v${app_ver})${C_RESET}"
    fi
    local arch_pass=0
    local arch="${C_GREEN}✔${C_RESET}"
    if [ -n "$app_arch" ] && [ "$app_arch" != "all" ]; then
        if ! echo "$app_arch" | grep -qw "$SYSTEM_ARCH"; then
            arch="${C_RED}✖${C_RESET} ${C_DIM}[$app_arch]${C_RESET}"
            arch_pass=1
        fi
    fi
    echo -e " 📦 名称: ${C_CYAN}${app_name}${C_RESET} ${C_DIM}[${app_id}]${C_RESET} ${ver_str}"
    echo -e " 👤 作者: ${app_author}"
    echo -e " ⚙️ 兼容: $arch"
    echo -e " 📝 简介: ${app_desc:-暂无描述}"
    [ -n "$app_url" ] && echo -e " 🔗 链接: ${app_url}"
    main_line

    if [ "$arch_pass" = "1" ]; then
        echo " ⚠️  警告: 不兼容 [ $SYSTEM_ARCH ] 系统架构！"
        return 0
    fi

    if [ "$app_status" = "uninstalled" ]; then
        read -r -p "应用可安装，是否安装？(y/N): " confirm
    elif [ "$app_status" = "upgradable" ]; then
        read -r -p "应用可更新，是否更新？(y/N): " confirm
    else
        read -r -p "应用已安装，是否重装？(y/N): " confirm
    fi
    local url="$(gh_to_raw "$source_url")"
    url="${MIRROR}${url}/HEAD/pkgs/${app_id}_${SYSTEM_ARCH}.tar.gz"
    case "$confirm" in
        y|Y)
            [ "$app_status" = "uninstalled" ] && confirm_install_to_rom
            echo -e "\n 🚀 正在准备安装/更新 ${C_YELLOW}${app_name}${C_RESET}..."
            app_install_from_url "$url"
            ;;
        *)
            echo -e "\n 已取消操作。"
            ;;
    esac
}

# 说明: 统一安装管道（解压校验 -> 覆盖安装 -> 注册 -> 执行钩子）
# 参数 $1: 待安装的 .tar.gz 文件路径
app_install_pipeline() {
    local pkg_file="$1"

    if [ ! -f "$pkg_file" ]; then
        echo -e " ❌ 安装失败: 未找到安装包文件 '$pkg_file'"
        return 1
    fi

    # 1. 创建带随机后缀的临时解压目录（防止残留/冲突）
    local random_id="$(${HEXDUMP:-hexdump} -n 4 -e '4/4 "%08x"' /dev/urandom 2>/dev/null || echo $$)"
    local tmp_extract="$MIKIT_TMP/mikit_pkg_${random_id}"
    mkdir -p "$tmp_extract"

    echo " 📦 正在解压并分析安装包..."

    tar -zxf "$pkg_file" -C "$tmp_extract" 2>/dev/null

    # 兼容性判定：定位解压后的实际目录（支持单层文件夹和无文件夹情况）
    local real_dir=""
    for d in "$tmp_extract"/*/; do
        [ -d "$d" ] && real_dir="${d%/}" && break
    done
    [ -z "$real_dir" ] && real_dir="$tmp_extract"

    # 2. 执行元信息与安全检测
    if ! check_app_package "$real_dir"; then
        rm -rf "$tmp_extract"
        return 1
    fi

    # 提取校验通过后获得的全局变量
    local app_id="$CHK_ID"
    local app_name="$CHK_NAME"
    local app_ver="$CHK_VER"

    echo " ⚙️ 正在安装: ${app_name} (v${app_ver}) ..."

    # 3. 确定安装目标路径
    local main_dir=""
    if is_app_installed "${app_id}"; then
        main_dir="$(get_main_dir "${app_id}")"
    else
        main_dir="$MIKIT_DATA_DIR"
        [ "$IS_FLASH" = "1" ] && main_dir="$MIKIT_DIR"
    fi

    local target_dir="$main_dir/apps/$app_id"
    local app_status=0

    if [ -d "$target_dir" ]; then
        echo " 🔄 正在进行覆盖/更新..."
        if [ -x "$target_dir/init" ]; then
            # 如果程序原本处于运行状态，记录并停止
            "$target_dir/init" status >/dev/null 2>&1 && app_status=1
            "$target_dir/init" stop >/dev/null 2>&1
        fi
    fi

    mkdir -p "$main_dir/apps/$app_id" "$main_dir/apps_data/$app_id"

    # 4. 拷贝文件（修正了通配符在双引号内失效的 Bug）
    cp -rf "$real_dir"/* "$target_dir/" 2>/dev/null

    # 赋予可执行权限
    chmod -R +x "$target_dir" 2>/dev/null

    # 5. 注册到 UCI 配置文件
    register_app "$app_id"

    # 6. 执行安装后钩子函数 (post_install)
    if [ -x "$target_dir/init" ]; then
        "$target_dir/init" post_install
        [ "$app_status" = "1" ] && "$target_dir/init" start
    fi

    # 7. 清理临时解压目录
    rm -rf "$tmp_extract"

    echo "\n ✅ ${app_name} 安装成功！"
    return 0
}

# 说明: 从任意远程 URL 地址下载并安装插件
app_install_from_url() {
    local url="$1"
    [ -z "$url" ] && return 1

    local tmp_download="$MIKIT_TMP/mikit_remote_app.tar.gz"
    echo " ⬇️ 正在从远程地址下载插件包..."
    echo " 🔗 URL: $url"

    curl -sSL --progress-bar --connect-timeout 5 "$url" -o "$tmp_download"
    if [ $? -ne 0 ] || [ ! -s "$tmp_download" ]; then
        echo -e "\n ❌ 下载失败: 无法访问远程文件或下载文件为空！"
        rm -f "$tmp_download" 2>/dev/null
        return 1
    fi

    # 交付管道处理
    app_install_pipeline "$tmp_download"
    local ret=$?

    rm -f "$tmp_download" 2>/dev/null
    return $ret
}

# 说明: 从本地路径 (如 /tmp/beszel.tar.gz 或 U盘路径) 安装
app_install_from_local() {
    local filepath="$1"

    if [ -z "$filepath" ]; then
        printf "请输入本地插件包的绝对路径 (.tar.gz): "
        read filepath
    fi

    if [ ! -f "$filepath" ]; then
        echo -e "\n ❌ 路径无效: 文件不存在！"
        mikit_pause
        return 1
    fi

    # 交付管道处理
    app_install_pipeline "$filepath"
    mikit_pause
}


# 说明: 一键生成适配 menu.common 的标准应用模板
create_new_app() {
    clear
    main_line
    print_center "Mi-Toolkit 开发模板" 4
    main_line
    printf "请输入应用 ID (纯字母/数字/下划线): "
    read t_id

    [ -z "$t_id" ] && { echo -e "\n ❌ 应用 ID 不能为空！"; return 1; }

    # ID 合法性校验
    ! check_valid_conf_name "$t_id" && return 1

    if is_app_installed "$t_id";then
        echo -e "\n ❌ 错误: 应用ID已存在！"
        return 1
    fi

    confirm_install_to_rom
    local main_dir="$MIKIT_DATA_DIR"
    if [ "$IS_FLASH" = "1" ]; then
        main_dir="$MIKIT_DIR"
    fi
    local target_dir="$main_dir/apps/$t_id"
    echo -e " 💡 提示: 最好输入半角英文字符避免影响布局 (例如: ${C_BLUE}My custom app1${C_RESET})"
    printf "请输入应用显示名称 : "
    read t_name
    [ -z "$t_name" ] && t_name="$t_id"

    printf "请输入作者姓名昵称: "
    read t_author
    [ -z "$t_author" ] && t_author="Anonymous"

    printf "请输入应用简写描述: "
    read t_desc
    [ -z "$t_desc" ] && t_desc="基于 Mi-Toolkit 的自定义应用"

    echo ""
    echo " 🚀 正在生成应用工程目录..."
    # 1. 创建应用文件夹结构
    mkdir -p "$target_dir" "$main_dir/apps_data/$t_id"

    # 2. 生成 manifest.json
    cat <<EOF > "$target_dir/manifest.json"
{
  "id": "${t_id}",
  "name": "${t_name}",
  "version": "1.0.0",
  "author": "${t_author}",
  "arch": "${SYSTEM_ARCH}",
  "desc": "${t_desc}",
  "href": ""
}
EOF

# 3. 生成符合 menu.common 架构的 init 脚本
    cat <<'EOF' > "$target_dir/init"
#!/bin/sh /etc/mk.rc.common
#APP_DIR APP_ID APP_NAME

# ------------------------------------------------------------------
# 1. procd 标准守护进程启动（推荐绝大多数应用使用）
# ------------------------------------------------------------------
start_service() {
    SCRIPT_PATH="$APP_DATA_DIR/${APP_ID}_daemon.sh"

    # 测试示例脚本  可换成二进制程序
    cat << DAEMON_EOF > "$SCRIPT_PATH"
#!/bin/sh

# 基础环境变量与配置
param="\$1"
APP_DATA_DIR="${APP_DATA_DIR}"
mkdir -p "\$APP_DATA_DIR"

# 每 10 秒记录一次时间戳
while true; do
    echo "[\$(date '+%Y-%m-%d %H:%M:%S')] \$param Heartbeat - PID: \$\$" >> "\$APP_DATA_DIR/heartbeat.log"
    sleep 10
done
DAEMON_EOF

    chmod +x "$SCRIPT_PATH"
    procd_open_instance

    # 纯 Shell 循环服务：每 10 秒打卡，并写入数据目录
    procd_set_param command "$SCRIPT_PATH" "入参"

    procd_set_param env HOME="$APP_DATA_DIR" TMPDIR="/tmp"

    procd_set_param respawn
    procd_set_param stderr 1

    procd_close_instance
}

# ------------------------------------------------------------------
# 2. 自定义服务控制（若应用无需 procd 守护，取消注释以下三个函数以覆盖默认实现）
# ------------------------------------------------------------------
#start_service() {
#    echo "🚀 正在启动服务..."
#    # 模拟手动拉起后台进程
#    "$APP_DIR/bin/runner.sh" >/dev/null 2>&1 &
#    echo $! > "$PID_FILE"
#}

#stop_service() {
#    echo "🛑 正在停止服务..."
#    if [ -f "$PID_FILE" ]; then
#        kill "$(cat "$PID_FILE")" 2>/dev/null
#        rm -f "$PID_FILE"
#    fi
#}

#service_running() {
#    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
#        echo "status=running pid=$(cat "$PID_FILE")"
#        return 0
#    fi
#    echo "status=stopped pid=0"
#    return 1
#}

# ------------------------------------------------------------------
# 3. 生命周期扩展钩子（按需取消注释使用）
# ------------------------------------------------------------------

# 服务停止后执行的清理动作
#stop_later() {
#    echo "🧹 执行停止后的临时文件清理..."
#    rm -f /tmp/${APP_ID}.tmp
#}

# 应用安装/部署完成后的初始化钩子
#post_install() {
#    echo "⚙️ 正在执行安装后初始化..."
#    [ -d "$APP_DIR/bin" ] && chmod +x "$APP_DIR/bin/"* 2>/dev/null
#}

# 应用卸载前的自定义清理动作
#pre_uninstall() {
#    echo "🗑️ 正在执行卸载前清理..."
#    # rm -rf "$DATA_DIR"
#}

EOF

# 3. 生成符合 menu.common 架构的 menu 脚本
    cat <<'EOF' > "$target_dir/menu"
#!/bin/sh /etc/mk.menu.common
#APP_DIR APP_ID APP_NAME

APP_INFO="纯 Shell 循环后台示例服务，启动后可查看日志输出。\n应用程序目录:$APP_DIR\n独立持久目录:$(cd "$APP_DATA_DIR" && pwd)"

# ------------------------------------------------------------------
# 1. 扩展菜单选项配置
# 语法格式: "菜单显示名称:调用的函数名|菜单显示名称:调用的函数名"
# 框架会自动在基础菜单（启动/停止/重启）后追加以下选项
# ------------------------------------------------------------------
OPTIONS="查看日志:custom_logs|修改配置:custom_config"

# ------------------------------------------------------------------
# 2. 内置函数重写（按需取消注释覆盖默认实现）
# ------------------------------------------------------------------

# 自定义启动
#start() {
#    echo "🚀 正在启动 $APP_NAME..."
#    "$APP_DIR/init" restart
#}

# 自定义停止
#stop() {
#    echo "🛑 正在停止 $APP_NAME..."
#    "$APP_DIR/init" stop
#}

# 自定义状态检测回调（用于菜单顶部状态显示）
#status() {
#    if service_is_running "$APP_DIR/init"; then
#        echo "status=running"
#        return 0
#    else
#        echo "status=stopped"
#        return 1
#    fi
#}

# ------------------------------------------------------------------
# 3. 扩展菜单自定义回调函数
# ------------------------------------------------------------------

# 📄 查看应用运行日志
custom_logs() {
    echo ""
    echo "=================== 📄 $APP_NAME 运行日志 ==================="
    if [ -f "$APP_DATA_DIR/heartbeat.log" ]; then
        tail -n 10 "$APP_DATA_DIR/heartbeat.log"
    else
        echo "⚠️ 暂未检测到日志文件: $log_file"
    fi
}

# ⚙️ 修改配置文件
custom_config() {
    echo ""
    echo "--- ⚙️ 修改 $APP_NAME 配置 ---"
}

EOF

    # 4. 赋予执行权限
    chmod +x "$target_dir/init"
    chmod +x "$target_dir/menu"
    # 5. 注册 UCI
    register_app "$t_id"



    echo " ✅ 应用模板创建成功！"
    echo " 📂 工程路径: $target_dir"

    mikit_pause
}