#!/bin/sh

main() {
  :
}

main