#!/bin/sh

. ./env.sh

set_mi_docker() {
  local TARGET_FILE="/etc/init.d/mi_docker"
  [ ! -f "$TARGET_FILE" ] && return 0

  local docker_conf=$(mikit_db get "docker")
  [ "$docker_conf" != "1" ] && return 0

  local PATCH_FLAG_BACK="/tmp/mi_docker_bak"
  if [ ! -f "$PATCH_FLAG_BACK" ]; then
    cp "$TARGET_FILE" "$PATCH_FLAG_BACK" 2>/dev/null
  fi

  local PATCH_FLAG="# __MI_DOCKER_PATCHED__"
  if grep -q "$PATCH_FLAG" "$TARGET_FILE" 2>/dev/null; then
    log "$TARGET_FILE 已经包含修改标识，跳过重复执行！" INFO
    return 0
  fi

  # 1. 取消掉挂载目录检测与完整性审查
  sed -i '/check_integrity()[[:space:]]*{/a \ \ \ \ \ \ \ \ return 0' "$TARGET_FILE"

  # 2. 去除 256M 内存和 0.5 核 CPU 的限制枷锁
  sed -i '/limit_resource()[[:space:]]*{/a \ \ \ \ \ \ \ \ return 0' "$TARGET_FILE"

  # 3. 将小米路由器定制的权限鉴权插件保镖进程的启动命令强行删除
  sed -i '/procd_open_instance/ {N; /\$PAUTHZ_BIN/ {N;N;N;d}}' "$TARGET_FILE"
  sed -i '/service_stop "$DOCKER_BIN\/$PAUTHZ_BIN"/d' "$TARGET_FILE"

  # 4. docker 日志配置
  sed -i 's/json_add_string "max-size" "50m"/json_add_string "max-size" "5m"\n\tjson_add_string "max-file" "3"/' "$TARGET_FILE"

  # 5. docker proxies 设置代理
  sed -i '/config_get_bool ipv6 globals ipv6 ""/a \ \ \ \ \ \ \ \ config_get proxy_server globals proxy_server ""' "$TARGET_FILE"
  sed -i '/json_add_boolean "iptables" "${iptables}"/a \        docker_ver_major=$("$DOCKER_BIN/dockerd" --version 2>/dev/null | awk '"'{print \$3}'"' | cut -d. -f1)\n        if [ -n "${proxy_server}" ] && [ "${docker_ver_major:-0}" -ge 23 ]; then\n                json_add_object "proxies"\n                json_add_string "http-proxy" "${proxy_server}"\n                json_add_string "https-proxy" "${proxy_server}"\n                json_add_string "no-proxy" "localhost,127.0.0.1"\n                json_close_object\n        fi' "$TARGET_FILE"

  # 6. 兼容新版 docker
  sed -i 's/pgrep containerd-shim/pgrep -f containerd-shim/g' "$TARGET_FILE"
  sed -i 's/xargs -r -n1 umount/xargs -r -n1 umount -f -l/g' "$TARGET_FILE"

  # 7. 提取版本与硬件信息
  CURRENT_VER=$(uci -c /usr/share/xiaoqiang get xiaoqiang_version.version.ROM 2>/dev/null || echo "0.0.0")

  # 8. 删掉原脚本中自带的旧配置 避免重复
  sed -i '/config_get experimental globals experimental ""/d' "$TARGET_FILE"
  sed -i '/config_get ip6tables globals ip6tables ""/d' "$TARGET_FILE"
  sed -i '/\[ -z "${experimental}" \] || json_add_boolean "experimental" "${experimental}"/d' "$TARGET_FILE"
  sed -i '/\[ -z "${ip6tables}" \] || json_add_boolean "ip6tables" "${ip6tables}"/d' "$TARGET_FILE"
  sed -i '/\[ -z "${ipv6}" \] || json_add_boolean "ipv6" "${ipv6}"/d' "$TARGET_FILE"
  sed -i '/\[ -z "${fixed_cidr_v6}" \] || json_add_string "fixed-cidr-v6" "${fixed_cidr_v6}"/d' "$TARGET_FILE"

  # 9. docker IPv6配置
  if echo "$CURRENT_VER 1.1.7" | awk '{
    split($1, a, "."); v1 = sprintf("%03d%03d%03d", a[1], a[2], a[3]);
    split($2, b, "."); v2 = sprintf("%03d%03d%03d", b[1], b[2], b[3]);
    if (v1 + 0 > v2 + 0) exit 0; else exit 1;
    }'; then
    log "当前固件版本 ($CURRENT_VER) ，开启 Docker IPv6。" INFO

    sed -i '/config_get_bool ipv6 globals ipv6 ""/a \ \ \ \ \ \ \ \ config_get experimental globals experimental ""' "$TARGET_FILE"
    sed -i '/config_get_bool ipv6 globals ipv6 ""/a \ \ \ \ \ \ \ \ config_get ip6tables globals ip6tables ""' "$TARGET_FILE"

    sed -i '/json_add_boolean "iptables" "${iptables}"/a \ \ \ \ \ \ \ \ [ -z "${ip6tables}" ] || json_add_boolean "ip6tables" "${ip6tables}"' "$TARGET_FILE"
    sed -i '/json_add_boolean "iptables" "${iptables}"/a \ \ \ \ \ \ \ \ [ -z "${experimental}" ] || json_add_boolean "experimental" "${experimental}"' "$TARGET_FILE"
    sed -i '/json_add_boolean "iptables" "${iptables}"/a \ \ \ \ \ \ \ \ [ -z "${fixed_cidr_v6}" ] || json_add_string "fixed-cidr-v6" "${fixed_cidr_v6}"' "$TARGET_FILE"
    sed -i '/json_add_boolean "iptables" "${iptables}"/a \ \ \ \ \ \ \ \ [ -z "${ipv6}" ] || json_add_boolean "ipv6" "${ipv6}"' "$TARGET_FILE"
  else
    log "当前固件版本 ($CURRENT_VER) 不支持，跳过开启 Docker IPv6。（需固件版本 > 1.1.7）" WARN
  fi

  # 10. 修改三方管理面板检测
  sed -i '/check_portainer()/,/}/ s:grep -sqw "$MANAGE_BIN":grep -sqE "$MANAGE_BIN|dpanel|portainer":' "$TARGET_FILE"

  # 写入修改标识
  echo -e "\n$PATCH_FLAG" >> "$TARGET_FILE"
  log "Set mi_docker succeed." INFO

  echo -e "\033[32m设置成功需手动重启 Docker! \033[0m"
}

main() {
  log "工具箱初始化脚本启动..." INFO

  # 1. 检查并追加环境变量
  if ! grep -q "mikit/data/profile" /etc/profile; then
      echo "[ -f /data/mikit/data/profile ] && . /data/mikit/data/profile  # mikit profile" >> /etc/profile
      . /etc/profile
      log "已将 mikit 环境变量加载命令写入 /etc/profile" INFO
  else
      log "环境变量已存在，无需重复添加" INFO
  fi

  # 2. 创建软链接
  log "创建程序核心软链接" INFO
  ln -sf "$MIKIT_DIR/core/rc.common" /etc/mk.rc.common
  ln -sf "$MIKIT_DIR/core/menu.common" /etc/mk.menu.common

  # 3. 添加防火墙/开机触发脚本
  if ! grep -q "init.sh" /etc/firewall.user 2>/dev/null; then
    echo "$MIKIT_DIR/core/init.sh" >> /etc/firewall.user
    log "已成功添加开机启动配置到 firewall.user" INFO
  else
    log "开机启动配置已存在，跳过添加" INFO
  fi

  # 4. 配置 Docker 补丁
  set_mi_docker

  # 5. 在 /etc/rc.local 顶部注入工具箱自启钩子（防止重复写入）
  if ! grep -q "rc.local.sh anti_touching" /etc/rc.local; then
    sed -i "1i [ -f /data/mikit/data/rc.local.sh ] && sh /data/mikit/data/rc.local.sh anti_touching >/dev/null 2>&1 &" /etc/rc.local
    log "已成功将反触碰自启钩子写入 /etc/rc.local" INFO
  fi
}

main