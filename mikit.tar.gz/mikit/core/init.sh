#!/bin/sh

. $MIKIT_DIR/core/env.sh

main() {
  log "工具箱初始化脚本启动..." INFO

  # 1. 检查并追加环境变量
  if ! grep -q "mikit/data/profile" /etc/profile; then
      echo "[ -f /data/mikit/data/profile ] && . /data/mikit/data/profile  # mikit profile" >> /etc/profile
      . /etc/profile
      log "已将 mikit 环境变量加载命令写入 /etc/profile" INFO
  else
      log "环境变量已存在，无需重复添加" INFO
  fi

  # 2. 创建软链接
  log "创建程序核心软链接" INFO
  ln -sf "$MIKIT_DIR/core/rc.common" /etc/mk.rc.common
  ln -sf "$MIKIT_DIR/core/menu.common" /etc/mk.menu.common

  # 3. 添加防火墙/开机触发脚本
  if ! grep -q "/core/init.sh" /etc/firewall.user 2>/dev/null; then
    echo "$MIKIT_DIR/core/init.sh" >> /etc/firewall.user
    log "已成功添加开机启动配置到 firewall.user" INFO
  else
    log "开机启动配置已存在，跳过添加" INFO
  fi

  # 4. 配置 Docker 补丁
  set_mi_docker

  # 5. 在 /etc/rc.local 顶部注入工具箱自启钩子（防止重复写入）
  if ! grep -q "rc.local.sh anti_touching" /etc/rc.local; then
    sed -i "1i [ -f /data/mikit/data/rc.local.sh ] && sh /data/mikit/data/rc.local.sh anti_touching >/dev/null 2>&1 &" /etc/rc.local
    log "已成功将反触碰自启钩子写入 /etc/rc.local" INFO
  fi
}

main