#!/bin/sh

# 说明: 通用日志打印与记录工具
# 用法: log "日志内容" [INFO|WARN|ERROR|DEBUG] [-s|-f]
# 特性: 支持时间戳、按级别过滤、标准输出与系统日志双通道
log() {
    local msg="$1"
    local level="${2:-INFO}"
    local mode="$3"

    # 1. 级别标准化与 DEBUG 全局开关过滤
    level="$(echo "$level" | tr '[:lower:]' '[:upper:]')"

    # 如果全局未开启 DEBUG 模式，则直接跳过 DEBUG 日志的打印
    if [ "$level" = "DEBUG" ] && [ "$MIKIT_DEBUG" != "1" ] && [ "$MIKIT_DEBUG" != "true" ]; then
        return 0
    fi

    # 2. 动态生成日志标签
    local tag="mikit"
    [ -n "$APP_ID" ] && [ "$APP_ID" != "mikit" ] && tag="mikit($APP_ID)"

    # 3. 获取当前精确到秒的时间戳 (格式: 2026-06-06 12:00:00)
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"

    # 4. 匹配颜色、Syslog 优先级和前缀
    local color=""
    local prio="6"
    local prefix="[INFO]"

    case "$level" in
        WARN)
            color="\033[33m"
            prio="4"
            prefix="[WARN]"
            ;;
        ERROR)
            color="\033[31m"
            prio="3"
            prefix="[ERROR]"
            ;;
        DEBUG)
            color="\033[36m"
            prio="7"
            prefix="[DEBUG]"
            ;;
        INFO|*)
            color="\033[32m"
            prio="6"
            prefix="[INFO]"
            ;;
    esac

    # 5. 标准输出打印（带时间戳、彩色、重置符）
    if [ "$mode" != "-f" ]; then
        echo -e "${timestamp} ${color}${prefix}${C_RESET} ${msg}"
    fi

    # 6. 写入 OpenWrt 系统日志 (logger)
    if [ "$mode" != "-s" ]; then
        logger -p "$prio" -t "$tag" "$prefix $msg" 2>/dev/null
    fi

    return 0
}

# 🛠️ Mikit 通用按键暂停提示函数
# 语法: mikit_pause [模式/自定义提示词]
mikit_pause() {
    local prompt=""

    case "$1" in
        "") prompt="\n按任意键继续..." ;;
        *)    prompt="\n$1" ;;
    esac

    printf "%b" "$prompt"

    # 优先尝试使用 stty 禁用 echo 和 buffer 以实现真正的“按任意单键”
    if command -v stty >/dev/null 2>&1; then
        local old_tty_settings
        old_tty_settings="$(stty -g 2>/dev/null)"
        stty raw -echo 2>/dev/null
        eval "$({ dd bs=1 count=1 2>/dev/null; } | { cat; })"
        stty "$old_tty_settings" 2>/dev/null
        echo ""
    else
        # 降级备用逻辑：依次尝试 read -n1 / read -k1 (zsh) / 普通 read
        read -n 1 -s -r 2>/dev/null || read -k 1 -s -r 2>/dev/null || read -r _
        echo ""
    fi
}


get_main_dir() {
    local app_id="$1"
    [ -z "$app_id" ] && return 1
    local lc="$(mikit_db get "${app_id}.is_flash")"
    local main_dir="$MIKIT_DATA_DIR"
    if [ "$lc" = "1" ]; then
        main_dir="$MIKIT_DIR"
    fi
    echo "$main_dir"
}

get_app_dir() {
  local app_id="$1"
  [ -z "$app_id" ] && return 1
  local maindir="$(get_main_dir "$app_id")"
  echo "$maindir/apps/$app_id"
}

get_app_data_dir() {
  local app_id="$1"
  [ -z "$app_id" ] && return 1
  local maindir="$(get_main_dir "$app_id")"
  echo "$maindir/apps_data/$app_id"
}

# 检查 conf_get "apps" 中是否包含指定的 app_id
# 参数: $1 - 待查找的 app_id
# 返回: 0 - 存在, 1 - 不存在
is_app_installed() {
    local appid="$1"
    [ -z "$appid" ] && return 1
    local apps
    apps=" $(mikit_db get "apps") "
    case "$apps" in
        *" $appid "*) return 0 ;;
        *)            return 1 ;;
    esac
}

detect_arch() {
    local raw_arch="$(uname -m)"
    case "$raw_arch" in
        # ARM 64 位
        aarch64|arm64)
            echo "arm64"
            ;;
        # ARM 32 位
        armv7*)
            echo "armv7"
            ;;
        armv5*|armv6*|arm)
            echo "armv5"
            ;;
        # x86 系列（归一化为通用命名）
        x86_64|amd64)
            echo "amd64"
            ;;
        i386|i686|x86)
            echo "386"
            ;;
        # MIPS 系列（识别小端 mipsle / 大端 mips）
        mips*)
            local cpu_info=""
            [ -f /proc/cpuinfo ] && cpu_info="$(cat /proc/cpuinfo)"
            if [ "$raw_arch" = "mipsel" ] || [ "$raw_arch" = "mips64el" ] || \
               echo "$cpu_info" | grep -qE -i "MT7621|MediaTek|little endian"; then
                echo "mipsle"
            else
                echo "mips"
            fi
            ;;
        # 兜底：原样输出
        *)
            echo "$raw_arch"
            ;;
    esac
    return 0
}


# 说明: 从 JSON 字符串中提取指定 key 的值 (自动降级兼容)
# 格式: get_json_val '{"name":"mikit","port":80}' "port"
get_json_val() {
    local json_str="$1"
    local key="$2"
    local val=""

    [ -z "$json_str" ] || [ -z "$key" ] && return 1

    # 1. 优先使用 OpenWrt 高性能的 jsonfilter
    if command -v jsonfilter >/dev/null 2>&1; then
        val=$(echo "$json_str" | jsonfilter -e "@.${key}" 2>/dev/null)
        if [ -n "$val" ] && [ "$val" != "null" ]; then
            echo "$val"
            return 0
        fi
    fi

    # 2. 次选 OpenWrt 内置的 jshn 解析
    if command -v jshn >/dev/null 2>&1; then
        eval "$(echo "$json_str" | jshn -r - 2>/dev/null)"
        eval "val=\"\$JSON_VAR_${key}\""
        if [ -n "$val" ]; then
            echo "$val"
            return 0
        fi
    fi

    # 3. 终极兜底：纯 grep + cut 文本匹配（适合简单的单层 JSON）
    echo "$json_str" | grep -o "\"$key\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" | cut -d'"' -f4
}

# 说明: 从 JSON 文件中提取指定 key 的值
# 格式: get_jsonfile_val "/path/to/config.json" "port"
get_jsonfile_val() {
    local json_file="$1"
    local key="$2"

    [ ! -f "$json_file" ] && return 1

    local content=""
    content="$(tr -d '\r' < "$json_file")"

    [ -z "$content" ] && return 1

    get_json_val "$content" "$key"
}

# 说明: 读取指定 app_id 的元数据信息
# 参数 $1: app_id
# 输出环境变量: META_NAME, META_VER, META_AUTHOR, META_DESC, META_ARCH
parse_app_meta() {
    local app_id="$1"
    local appdir="$2"
    [ -z "$app_id" ] && return 1

    [ -z "$appdir" ] && appdir="$(get_app_dir "$app_id")"
    local manifest="$appdir/manifest.json"

    APP_NAME="$app_id"
    APP_VERSION="0.0.0"
    APP_AUTHOR="匿名"
    APP_DESC="暂无描述"
    APP_ARCH="all"
    APP_URL=""

    if [ -f "$manifest" ]; then
        local name="$(get_jsonfile_val "$manifest" "name" 2>/dev/null)"
        local ver="$(get_jsonfile_val "$manifest" "version" 2>/dev/null)"
        local author="$(get_jsonfile_val "$manifest" "author" 2>/dev/null)"
        local desc="$(get_jsonfile_val "$manifest" "desc" 2>/dev/null)"
        local arch="$(get_jsonfile_val "$manifest" "arch" 2>/dev/null)"
        local url="$(get_jsonfile_val "$manifest" "url" 2>/dev/null)"

        [ -n "$name" ] && APP_NAME="$name"
        [ -n "$ver" ] && APP_VERSION="$ver"
        [ -n "$author" ] && APP_AUTHOR="$author"
        [ -n "$desc" ] && APP_DESC="$desc"
        [ -n "$arch" ] && APP_ARCH="$arch"
        [ -n "$url" ] && APP_URL="$url"
    fi
}

# 说明: 比较两个版本号，如果 $1 > $2 则返回 0 (true)，否则返回 1 (false)
# 示例: version_gt "1.2.10" "1.2.2" -> 返回 0
# 判断 $1 是否大于 $2 ($1 > $2)
# 返回 0 (true) 表示大于，返回 1 (false) 表示不大于
version_gt() {
    [ "$1" = "$2" ] && return 1

    # 剥离版本号开头的 'v' 字符 (如 v1.2.0 -> 1.2.0)
    local v1="${1#v}."
    local v2="${2#v}."

    while [ -n "$v1" ] || [ -n "$v2" ]; do
        # 提取点号前的第一段数字
        local n1="${v1%%.*}"
        local n2="${v2%%.*}"

        # 为空时补 0
        n1="${n1:-0}"
        n2="${n2:-0}"

        if [ "$n1" -gt "$n2" ]; then
            return 0
        elif [ "$n1" -lt "$n2" ]; then
            return 1
        fi

        # 截掉已比较的第一段
        v1="${v1#*.}"
        v2="${v2#*.}"
    done

    return 1
}

# 将 GitHub 网页链接转换为 Raw 原始文件直链，并去除末尾多余的斜杠
# 参数: $1 - GitHub URL
# 返回: 转换后的 Raw URL (参数为空时返回 1)
gh_to_raw() {
    [ -z "$1" ] && return 1
    echo "$1" | sed -E \
        -e 's|https?://(www\.)?github\.com/|https://raw.githubusercontent.com/|g' \
        -e 's|/blob/|/|g' \
        -e 's|/+$||'
}

# 功能描述: 在指定宽度的终端边框内将文本格式化并居中输出
# 参数说明:
#   $1 - text          : [必须] 要输出的文本（支持含 ANSI 颜色代码及 Emoji/中文）
#   $2 - manual_offset : [可选] 宽字符（Emoji/中文）的补偿个数，默认 0
#                        说明：1 个 Emoji 或 1 个中文在 Shell 字符数算 1，但终端显示占 2 宽，
#                        因此每有 1 个 Emoji 或 1 个中文，此值需 +1（例如 2 个 Emoji + 2 个中文 = 4）
#   $3 - total_width   : [可选] 目标对齐的总边框宽度，默认 54
print_center() {
    local text="${1:-0}"
    local manual_offset="${2:-0}" # 手动补重：1个Emoji或1个汉字算 1
    local total_width="${3:-60}"
    local plain_text=$(echo -e "$text" | sed 's/\x1b\[[0-9;]*m//g; s/\033\[[0-9;]*m//g')
    local real_width=$(( ${#plain_text} - manual_offset ))
    if [ "$real_width" -ge "$total_width" ]; then
        printf "%b\n" "$text"
        return
    fi
    local pad_left=$(( (total_width - real_width) / 2 ))
    printf "%*s%b\n" "$pad_left" "" "$text"
}

confirm_install_to_rom() {
    echo -e " 💡 提示: （内置硬盘设备请忽略此项）"
    echo -e "${C_DIM}   • 默认选项：安装至设置的数据目录(推荐)${C_RESET}"
    echo -e "${C_DIM}   • 强制 ROM：适合无内置硬盘设备需随系统常驻防掉盘的服务${C_RESET}"
    echo -e "${C_DIM}   • 注意事项：请提前确认 ROM (Flash) 剩余空间及应用无依赖环境${C_RESET}"
    read -r -p "是否强制安装到 ROM Flash ？[y/N]: " is_rom
    case "$is_rom" in
        [yY])
          echo "--> 安装位置 ROM Flash"
          IS_FLASH="1" ;;
        *)
          echo "--> 安装位置保持默认"
          IS_FLASH="0" ;;
    esac
}

register_app() {
    local app_id="$1"
    [ -z "$app_id" ] && return 1
    mikit_db rmlist "apps" "$app_id"
    mikit_db add "apps" "$app_id"
    mikit_db set "$app_id.source_id" "$source_id"
    mikit_db set "$app_id.is_flash" "$IS_FLASH"
    local appdir="$(get_app_dir "$app_id")"
    mikit_db set "$app_id.version" "$(mikit_db get "$appdir/manifest.json" "version")"
}

uninstall_app() {
    local appid="$1"
    [ -z "$appid" ] && return 1
    local main_dir="$(get_main_dir "$appid")"
    echo " ⚠️  警告: 确定要删除/卸载 [ $appid ] 吗？"
    read -r -p "请确认 (y/N): " confirm
    if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ]; then
        read -r -p "是否删除 [ $appid ] 用户数据目录及配置？ (y/N): " confirm
        if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ]; then
            echo "--> 将删除用户目录和应用配置"
        else
            echo "--> 将保留用户目录 ($main_dir/apps_data/$appid) 和应用配置"
        fi
        "$main_dir/apps/$appid/init" stop 2>/dev/null
        echo " 🗑️  正在卸载插件..."
        "$main_dir/apps/$appid/init" pre_uninstall 2>/dev/null
        rm -rf "$main_dir/apps/$appid"

        mikit_db rmlist "mikit.apps" "$appid" 2>/dev/null

        if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ]; then
            rm -rf "$main_dir/apps_data/$appid"
            mikit_db del_sec "$appid"
        fi
        echo -e "\n ✅ 卸载完成！"
    else
        echo -e "\n ❌ 已取消删除操作。"
        return 1
    fi
}

extract_domain() {
    local url="$1"
    [ -z "$url" ] && return 1
    local domain="${url#*://}"
    domain="${domain%%/*}"
    domain="${domain%%:*}"
    domain="${domain%%\?*}"
    echo "$domain"
}

