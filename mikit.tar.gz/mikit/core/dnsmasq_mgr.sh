#!/bin/sh

_UCI_DNS_FILE="dnsmasq"
_UCI_CONFIG_DIR="$MIKIT_DIR/data"
_DATA_DNS_FILE="mikit_hosts.conf"

# 初始化基础配置结构（符合标准的 dnsmasq uci 结构）
dns_init_config_if_needed() {
    local config_file="$_UCI_CONFIG_DIR/$_UCI_DNS_FILE"
    if [ ! -f "$config_file" ]; then
        cat <<EOF > "$config_file"
config dnsmasq
EOF
    fi
}

# 1A. 查询全部：展示标准 dnsmasq 格式
dns_query_all() {
    local addresses=$(uci -c "$_UCI_CONFIG_DIR" get "$_UCI_DNS_FILE.@dnsmasq[0].address" 2>/dev/null)
    if [ -z "$addresses" ]; then
        echo "当前没有配置任何规则。"
        return 0
    fi
    echo "=== 当前配置的 dnsmasq 规则 ==="
    for addr in $addresses; do
        echo "address=$addr"
    done
}

# 1B. 单个查询：输入域名，直接输出对应的 IP
dns_query_one() {
    local target_domain="$1"
    [ -z "$target_domain" ] && return 0
    local addresses=$(uci -c "$_UCI_CONFIG_DIR" get "$_UCI_DNS_FILE.@dnsmasq[0].address" 2>/dev/null)
    [ -z "$addresses" ] && return 0

    echo "$addresses" | tr ' ' '\n' | awk -F'/' -v target="$target_domain" '
    $2 == target {
        print $3;
        exit;
    }'
}

# 2. 生成标准的 dnsmasq 配置文件
dns_generate_dnsmasq_file() {
    local status=$(mikit_db get "dnsmasq")
    [ "$status" != "1" ] && return 0
    local output_path="$MIKIT_DIR/mikit_hosts.conf"
    local addresses=$(uci -c "$_UCI_CONFIG_DIR" get "$_UCI_DNS_FILE.@dnsmasq[0].address" 2>/dev/null)

    if [ -z "$addresses" ]; then
        # 如果规则已经为空，生成空文件并重载 dnsmasq
        rm "/etc/dnsmasq.d/$_DATA_DNS_FILE" >/dev/null 2>&1
        if [ -x /etc/init.d/dnsmasq ]; then
            /etc/init.d/dnsmasq reload >/dev/null 2>&1
        fi
        return 0
    fi

    {
        echo "# =========================================="
        echo "# Auto-generated dnsmasq configuration"
        echo "# Generated at: $(date)"
        echo "# =========================================="
        for addr in $addresses; do
            echo "address=$addr"
        done
    } > "$_UCI_CONFIG_DIR/$_DATA_DNS_FILE"

    ln -sf "$_UCI_CONFIG_DIR/$_DATA_DNS_FILE" "/etc/dnsmasq.d/$_DATA_DNS_FILE"
    if [ -x /etc/init.d/dnsmasq ]; then
        /etc/init.d/dnsmasq reload >/dev/null 2>&1
    fi
}

dns_clear_github() {
    uci -c "$_UCI_CONFIG_DIR" delete "$_UCI_DNS_FILE.@dnsmasq[0].address" 2>/dev/null
    uci -c "$_UCI_CONFIG_DIR" commit "$_UCI_DNS_FILE"
}

dns_clear_all() {
    echo " 正在擦除所有 DNSMASQ 域名规则..."
    uci -c "$_UCI_CONFIG_DIR" delete "$_UCI_DNS_FILE.@dnsmasq[0].address" 2>/dev/null
    uci -c "$_UCI_CONFIG_DIR" commit "$_UCI_DNS_FILE"
    dns_generate_dnsmasq_file
    echo -e "\n ✅ 所有规则已清空！"
}

# 3C. 删除单条指定规则
dns_delete_one() {
    local target_domain="$1"
    if [ -z "$target_domain" ]; then
        echo -e "\n ❌ 必须提供要删除的域名！"
        return 1
    fi

    local addresses=$(uci -c "$_UCI_CONFIG_DIR" get "$_UCI_DNS_FILE.@dnsmasq[0].address" 2>/dev/null)
    if [ -z "$addresses" ]; then
        echo -e "\n ❌ 当前没有任何规则可供删除。"
        return 0
    fi

    local found=0
    uci -c "$_UCI_CONFIG_DIR" delete "$_UCI_DNS_FILE.@dnsmasq[0].address" 2>/dev/null

    for addr in $addresses; do
        local d=$(echo "$addr" | awk -F'/' '{print $2}')
        local i=$(echo "$addr" | awk -F'/' '{print $3}')

        if [ "$d" = "$target_domain" ]; then
            found=1
        else
            uci -c "$_UCI_CONFIG_DIR" add_list "$_UCI_DNS_FILE.@dnsmasq[0].address"="/$d/$i"
        fi
    done

    uci -c "$_UCI_CONFIG_DIR" commit "$_UCI_DNS_FILE"

    if [ "$found" -eq 1 ]; then
        dns_generate_dnsmasq_file
        echo -e "\n ✅ 成功删除域名规则: $target_domain"
    else
        echo -e "\n ⚠️ 未找到关于域名 [$target_domain] 的记录。"
    fi
}

# 4. 保存单条规则 (直接用标准格式 /域名/IP)
dns_set() {
    local domain="$1"
    local ip="$2"
    if [ -z "$domain" ] || [ -z "$ip" ]; then
        echo -e "\n ❌ 必须提供域名和 IP！"
        return 1
    fi

    dns_init_config_if_needed
    uci -c "$_UCI_CONFIG_DIR" add_list "$_UCI_DNS_FILE.@dnsmasq[0].address"="/$domain/$ip"
    uci -c "$_UCI_CONFIG_DIR" commit "$_UCI_DNS_FILE"
    dns_generate_dnsmasq_file
    echo -e "\n ✅ 设置成功"
}

# 5. 更新 GitHub 规则
dns_update() {
    local url="https://cdn.jsdelivr.net/gh/maxiaof/github-hosts/hosts"
    echo "开始下载最新规则..."
    LOCAL_TMP="$MIKIT_TMP/github_hosts.txt"
    curl -sSL --connect-timeout 5 -m 10 "$url" -o "$LOCAL_TMP"
    if [ $? -ne 0 ] || [ ! -s "$LOCAL_TMP" ]; then
        echo -e "\n ❌ 下载失败或文件为空！"
        return 1
    fi

    dns_init_config_if_needed
    dns_clear_github

    echo "正在解析并以 dnsmasq 标准格式写入..."
    while read -r line; do
        case "$line" in ""|"#"*) continue ;; esac
        set -- $line
        ip="$1"
        shift
        case "$ip" in *[0-9]*.*[0-9]*.*[0-9]*.*[0-9]*)
            for domain in "$@"; do
                case "$domain" in "#"*) break ;; esac
                uci -c "$_UCI_CONFIG_DIR" add_list "$_UCI_DNS_FILE.@dnsmasq[0].address"="/$domain/$ip"
            done
        esac
    done < "$LOCAL_TMP"

    uci -c "$_UCI_CONFIG_DIR" commit "$_UCI_DNS_FILE"
    rm -f "$LOCAL_TMP"

    dns_generate_dnsmasq_file
    echo -e "\n ✅ GitHub Hosts 更新完成！"
}

# 控制台主菜单
show_domain_menu() {
    while true; do
        clear
        local status=$(mikit_db get "dnsmasq")
        local status_str="🛑"
        [ "$status" = "1" ] && status_str="🟢"
        main_line
        print_center "${C_BOLD}${C_GREEN}🌐 DNSMASQ 域名路由管理${C_RESET} ${status_str}" 8
        print_center "${C_DIM}DNS & Hosts Toolkit${C_RESET}"
        sub_line
        echo -e "  ${C_GREEN}1)${C_RESET} 🔄 启用/禁用"
        echo -e "  ${C_GREEN}2)${C_RESET} 📜 查看全部规则"
        echo -e "  ${C_GREEN}3)${C_RESET} ✍️ 添加/修改规则"
        echo -e "  ${C_GREEN}4)${C_RESET} 🐙 更新 GitHub 规则"


        sub_line
        echo -e "  ${C_RED}7)${C_RESET} 🧹 清理 GitHub 规则"
        echo -e "  ${C_RED}8)${C_RESET} 🗑️ 移除单条规则"
        echo -e "  ${C_RED}9)${C_RESET} ⚠️ 清空所有规则"
        echo -e "  ${C_GRAY}0)${C_RESET} 🔙 返回"
        main_line
        printf " 👉 请选择 [${C_BOLD}0-7${C_RESET}]: "
        read gh_choice
        echo ""
        case "$gh_choice" in
            1)
              echo -e " 当前状态：$status_str"
              read -r -p "是否启用规则？ (y/N): " confirm
              if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ]; then
                  mikit_db set "dnsmasq" "1"
                  dns_generate_dnsmasq_file
                  echo -e "\n ✅ 已启用"

              else
                  mikit_db set "dnsmasq" "0"
                  if [ -f "/etc/dnsmasq.d/$_DATA_DNS_FILE" ]; then
                      rm "/etc/dnsmasq.d/$_DATA_DNS_FILE" >/dev/null 2>&1
                      /etc/init.d/dnsmasq reload >/dev/null 2>&1
                  fi
                  echo -e "\n ❌ 已禁用"
              fi
              mikit_pause
              ;;
            2)
                dns_query_all
                mikit_pause
                ;;

            3)
                printf "请输入域名: "
                read set_d
                printf "请输入目标 IP: "
                read set_ip
                if [ -n "$set_d" ] && [ -n "$set_ip" ]; then
                    dns_set "$set_d" "$set_ip"
                else
                    echo -e "\n ❌ 域名和 IP 不能为空！"
                fi
                mikit_pause
                ;;

            4)
                dns_update
                mikit_pause
                ;;
            7)
                printf " ⚠️ 确定要清理 GitHub 规则吗？[y/N]: "
                read confirm
                case "$confirm" in
                    y|Y)
                        dns_clear_github
                        dns_generate_dnsmasq_file
                        echo -e "\n ✅ 清理 GitHub 规则完成！"
                        ;;
                    *) echo "已取消。" ;;
                esac
                mikit_pause
                ;;
            8)
                echo ""
                printf "请输入要删除的域名: "
                read del_d
                if [ -n "$del_d" ]; then
                    dns_delete_one "$del_d"
                fi
                echo ""
                mikit_pause
                ;;
            9)
                printf " ⚠️ 确定要彻底清空【所有】规则吗？此操作不可逆！[y/N]: "
                read confirm
                case "$confirm" in
                    y|Y) dns_clear_all ;;
                    *) echo -e "\n已取消清空。" ;;
                esac
                mikit_pause
                ;;
            0)
                break
                ;;
            *)
                echo -e "\n ❌ 无效选项，请重新输入！"
                mikit_pause
                ;;
        esac
    done
}