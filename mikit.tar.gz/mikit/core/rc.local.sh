#!/bin/sh

. $MIKIT_DIR/core/env.sh

set_dropbear() {
  # 固定 SSH 密钥（以防止系统重启后指纹信息发生改变）
  local KEY_DIR="$MIKIT_DIR/temporary"
  local ETC_DIR="/etc/dropbear"

  # 确保临时目录存在
  mkdir -p "$KEY_DIR"

  if dropbearkey -y -f "$KEY_DIR/dropbear_rsa_host_key" >/dev/null 2>&1; then
    mkdir -p "$ETC_DIR"
    cp -f "$KEY_DIR"/dropbear_* "$ETC_DIR/" 2>/dev/null
    /etc/init.d/dropbear restart >/dev/null 2>&1
  else
    if [ -f "$ETC_DIR"/dropbear_rsa_host_key ]; then
      cp -f "$ETC_DIR"/dropbear_* "$KEY_DIR/" 2>/dev/null
    fi
  fi
  log "dropbear SSH 密钥初始化完成"
}

set_dnsmasq() {
  local conf=$(mikit_db get "dnsmasq")
  [ "$conf" != "1" ] && return 0
  dns_generate_dnsmasq_file
  log "dnsmasq 初始化完成"
}

set_nginx() {
  :
}

start_app() {
    local app_list="$(mikit_db get "apps")"
    [ -z "$app_list" ] && return 0

    log "正在检查并启动自启应用..."

    local sorted_apps=""
    for app_id in $app_list; do
        local enable="$(mikit_db get "${app_id}.auto_start")"
        [ "$enable" != "1" ] && continue

        local priority="$(mikit_db get "${app_id}.priority")"
        [ -z "$priority" ] && priority="99"

        sorted_apps="${sorted_apps}${priority} ${app_id}\n"
    done

    [ -z "$sorted_apps" ] && return 0

    printf "%b" "$sorted_apps" | sort -n | while read -r priority app_id; do
        [ -z "$app_id" ] && continue
        local start_cmd=$(get_app_dir "$app_id")

        log "[$app_id] 正在启动 (优先级: $priority)..." INFO -s

        # 执行对应的启动脚本
        [ -f "$start_cmd/init" ] && eval "$start_cmd/init restart >/dev/null 2>&1 &"
    done

    log "自启应用加载完成。" INFO
}

set_docker_profile_path() {
  [ ! -f /etc/init.d/mi_docker ] && return 0
  local docker_conf=$(mikit_db get "docker")
  [ "$docker_conf" != "1" ] && return 0

  DEVICE_UUID=$(uci -q get mi_docker.settings.device_uuid)
  [ -n "$DEVICE_UUID" ] && USB_PATH=$(storage dump 2>/dev/null | grep -C3 "${DEVICE_UUID:-invalid-uuid}" | grep target: | awk '{print $2}')

  if [ -z "$USB_PATH" ]; then
    log "set_docker_profile_path 未检测到可用的 USB 设备" WARN
    return 1
  }

  # 导出全局变量，供后面的函数（如 set_entware）使用
  export USB_PATH

  # 检测并创建/更新“/data/usb”链接
  CURRENT_LINK=$(readlink /data/usb)
  if [ "$CURRENT_LINK" = "$USB_PATH" ]; then
    log "Symlink /data/usb is already correct (pointing to $USB_PATH)." INFO
  else
    log "Updating symlink: /data/usb -> $USB_PATH" INFO
    rm -f /data/usb
    ln -sf "$USB_PATH" /data/usb
  fi
}

set_entware() {
  # 必须确保 USB_PATH 已经通过前面的函数获取到
  [ -z "$USB_PATH" ] && return 0

  local ENTWARE_PATH="${USB_PATH}/.entware"
  local BIN="etc/init.d/rc.unslung"

  if [ -f "/opt/$BIN" ]; then
    log "Entware 环境已挂载运行中" INFO
    return 0
  fi

  if [ -f "$ENTWARE_PATH/$BIN" ]; then
    [ -d "/opt" ] && [ "$(ls -A /opt 2>/dev/null)" ] && cp -a /opt/. "$ENTWARE_PATH/" > /dev/null 2>&1
    [ -d "/root" ] && [ "$(ls -A /root 2>/dev/null)" ] && cp -a /root/. "$ENTWARE_PATH/root" > /dev/null 2>&1

    mount --bind "$ENTWARE_PATH" /opt
    if [ $? -ne 0 ]; then
        log "Entware 挂载 /opt 失败！" ERROR
        return 1
    fi

    mount --bind "$ENTWARE_PATH/root" /root
    if [ $? -ne 0 ]; then
        log "Entware 挂载 /root 失败！" ERROR
        return 1
    fi

    if ! grep -q "/opt/bin:/opt/sbin:/opt/usr/bin" /etc/profile 2>/dev/null; then
        echo 'export PATH=/opt/bin:/opt/sbin:/opt/usr/bin:$PATH' >> /etc/profile
    fi
    . /etc/profile > /dev/null 2>&1
    log "Entware 环境初始化并启动成功" INFO
  else
    log "未检测到 Entware 离线包 ($ENTWARE_PATH)" INFO
  fi
}

# --- 执行入口控制 ---
[ "$1" != "anti_touching" ] && return 1

# 1. 先初始化 Docker 路径并导出 USB_PATH 变量
set_docker_profile_path

# 2. 依次加载各项服务
set_dropbear
set_entware
start_app
set_dnsmasq
set_nginx

# 3. 执行用户自定义脚本
log "运行用户自定义脚本" INFO
[ -f $MIKIT_DIR/data/custom_script.sh ] && $MIKIT_DIR/data/custom_script.sh >/dev/null 2>&1