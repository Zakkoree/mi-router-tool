#!/bin/sh
# /data/mi-toolkit/core/cron_engine.sh

_UCI_CRON_FILE="mikit_cron"
_UCI_CONFIG_DIR="$MIKIT_DIR/data"
CRON_TARGET="/etc/crontabs/root"

# 获取 UCI 动态路径参数（优先使用 $CONFIG_DIR，若无则自动应用 $_UCI_CONFIG_DIR）
_get_uci_path_opt() {
    local config_dir="${CONFIG_DIR:-$_UCI_CONFIG_DIR}"
    [ -n "$config_dir" ] && echo "-c $config_dir" || echo ""
}

# 校验 Cron 表达式（标准 5 段语法）
_validate_cron_expr() {
    local expr="$1"
    local count=$(echo "$expr" | awk '{print NF}')
    if [ "$count" -ne 5 ]; then
        echo -e "\n ❌ Cron 表达式必须包含 5 个部分（分 时 日 月 周），当前有 $count 个"
        return 1
    fi
    return 0
}

# 重启/刷新系统 cron 服务
cron_reload() {
    if [ -x "/etc/init.d/cron" ]; then
        /etc/init.d/cron reload >/dev/null 2>&1 || /etc/init.d/cron restart >/dev/null 2>&1
    elif command -v crontab >/dev/null 2>&1; then
        crontab "$CRON_TARGET" >/dev/null 2>&1
    fi
}


# 单个任务增量写入 crontab（无需 reload 重启服务）
cron_sync_item() {
    local task_id="$1"
    local path_opt="$(_get_uci_path_opt)"

    [ -z "$task_id" ] && return 1

    mkdir -p "$(dirname "$CRON_TARGET")"
    [ -f "$CRON_TARGET" ] || touch "$CRON_TARGET"

    # 1. 先安全剔除旧的对应行（保障停用/修改表达式时实时生效）
    sed -i "/# MIKIT_CRON:${task_id}:/d" "$CRON_TARGET" 2>/dev/null

    # 2. 读取 UCI 最新状态
    local enabled=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${task_id}.enabled")
    local expr=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${task_id}.cron_expr")
    local cmd=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${task_id}.command")
    local tag=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${task_id}.tag")

    # 3. 启用且配置齐全时追加
    if [ "$enabled" = "1" ] && [ -n "$expr" ] && [ -n "$cmd" ]; then
        echo "${expr} ${cmd} # MIKIT_CRON:${task_id}:${tag}" >> "$CRON_TARGET"
    fi
}

# 单个任务删除
cron_unsync_item() {
    local task_id="$1"

    [ -z "$task_id" ] && return 1

    # 直接利用 sed 删掉对应的行，即刻生效
    if [ -f "$CRON_TARGET" ]; then
        sed -i "/# MIKIT_CRON:${task_id}:/d" "$CRON_TARGET" 2>/dev/null
    fi
}

cron_sync_all() {
    local path_opt="$(_get_uci_path_opt)"
    local global_enabled=$(uci $path_opt -q get "${_UCI_CRON_FILE}.global.enabled")

    mkdir -p "$(dirname "$CRON_TARGET")"
    [ -f "$CRON_TARGET" ] || touch "$CRON_TARGET"

    # 1. 原地删掉所有带 MIKIT_CRON 标记的旧任务（直接操作原文件）
    sed -i '/# MIKIT_CRON/d' "$CRON_TARGET" 2>/dev/null

    # 2. 默认 global 不存在时视为开启 (1)
    if [ "${global_enabled:-1}" = "1" ]; then
        # 遍历 UCI 中所有类型为 'task' 的 section
        for section in $(uci $path_opt -q show "$_UCI_CRON_FILE" | grep "=task" | awk -F'.' '{print $2}' | awk -F'=' '{print $1}'); do
            local tag=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${section}.tag")
            local enabled=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${section}.enabled")
            local expr=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${section}.cron_expr")
            local cmd=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${section}.command")

            if [ "$enabled" = "1" ] && [ -n "$expr" ] && [ -n "$cmd" ]; then
                # 直接追加写入原文件
                echo "${expr} ${cmd} # MIKIT_CRON:${section}:${tag}" >> "$CRON_TARGET"
            fi
        done
    fi

    # BusyBox cron 监控原文件时间戳即可自动重载，甚至不需要 cron_reload
}


# 1. 根据 task_id 获取任务详情
cron_get_by_id() {
    local task_id="$1"
    local path_opt="$(_get_uci_path_opt)"

    [ -z "$task_id" ] && return 1

    if ! uci $path_opt -q show "${_UCI_CRON_FILE}.${task_id}" >/dev/null 2>&1; then
        echo -e "\n ⚠️ 未找到定时任务 [${task_id}]"
        return 1
    fi

    local tag=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${task_id}.tag")
    local enabled=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${task_id}.enabled")
    local expr=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${task_id}.cron_expr")
    local cmd=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${task_id}.command")
    local remark=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${task_id}.remark")

    echo "=== 📌 定时任务信息: [${task_id}] ==="
    echo "  🏷️ TAG    : ${tag:-N/A}"
    echo "  🚀 Enabled: $([ "$enabled" = "1" ] && echo "🟢 已启用" || echo "🔴 已禁用")"
    echo "  ⏱️ Expr   : ${expr}"
    echo "  💻 Cmd    : ${cmd}"
    echo "  📝 Remark : ${remark:-无}"

    return 0
}

# 2. 查找匹配指定 Tag 的所有任务
cron_get_by_tag() {
    local target_tag="$1"
    local path_opt="$(_get_uci_path_opt)"
    local found=0

    [ -z "$target_tag" ] && return 1

    for section in $(uci $path_opt -q show "$_UCI_CRON_FILE" | grep "=task" | awk -F'.' '{print $2}' | awk -F'=' '{print $1}'); do
        local tag=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${section}.tag")
        if [ "$tag" = "$target_tag" ]; then
            cron_get_by_id "$section"
            found=1
        fi
    done

    if [ "$found" -eq 0 ]; then
        echo -e "\n ⚠️ 未找到 TAG 为 [${target_tag}] 的任务"
        return 1
    fi
    return 0
}

# 3. 检查任务是否存在 (通过 task_id 或 tag)
cron_has_task() {
    local task_id="$1"
    local path_opt="$(_get_uci_path_opt)"

    [ -z "$task_id" ] && return 1

    uci $path_opt -q show "${_UCI_CRON_FILE}.${task_id}" >/dev/null 2>&1
    return $?
}

# 任务设置与删除接口

# 1. 创建/更新某个任务
# 语法: cron_set_task <task_id> <tag> <enabled:1|0> <cron_expr> <command> [remark]
cron_set_task() {
    local task_id="$1"
    local tag="$2"
    local enabled="$3"
    local cron_expr="$4"
    local command="$5"
    local remark="$6"
    local path_opt="$(_get_uci_path_opt)"
    local config_dir="${CONFIG_DIR:-$_UCI_CONFIG_DIR}"

    if [ -z "$task_id" ] || [ -z "$cron_expr" ] || [ -z "$command" ]; then
        echo -e "\n ❌ 参数缺失！语法: cron_set_task <task_id> <tag> <enabled> <cron_expr> <command> [remark]"
        return 1
    fi

    if ! _validate_cron_expr "$cron_expr"; then
        return 1
    fi

    # 自动保障配置文件和目录存在
    if [ -n "$config_dir" ]; then
        mkdir -p "$config_dir"
        [ -f "${config_dir}/${_UCI_CRON_FILE}" ] || touch "${config_dir}/${_UCI_CRON_FILE}"
    fi

    if ! uci $path_opt -q show "${_UCI_CRON_FILE}.${task_id}" >/dev/null 2>&1; then
        uci $path_opt set "${_UCI_CRON_FILE}.${task_id}=task"
    fi

    uci $path_opt set "${_UCI_CRON_FILE}.${task_id}.tag=${tag}"
    uci $path_opt set "${_UCI_CRON_FILE}.${task_id}.enabled=${enabled:-0}"
    uci $path_opt set "${_UCI_CRON_FILE}.${task_id}.cron_expr=${cron_expr}"
    uci $path_opt set "${_UCI_CRON_FILE}.${task_id}.command=${command}"
    if [ -n "$remark" ]; then
        uci $path_opt set "${_UCI_CRON_FILE}.${task_id}.remark=${remark}"
    else
        uci $path_opt delete "${_UCI_CRON_FILE}.${task_id}.remark" 2>/dev/null
    fi

    uci $path_opt commit "$_UCI_CRON_FILE"
    cron_sync_item "$task_id"
    echo -e "\n ✅ 已成功保存任务 [${task_id}]"
}

# 2. 根据 task_id 删除指定任务
cron_del_by_id() {
    local task_id="$1"
    local path_opt="$(_get_uci_path_opt)"

    [ -z "$task_id" ] && return 1

    uci $path_opt delete "${_UCI_CRON_FILE}.${task_id}" 2>/dev/null
    uci $path_opt commit "$_UCI_CRON_FILE"
    cron_unsync_item "$task_id"
    echo -e "\n ✅ 已成功删除任务 [${task_id}]"
    return 0
}

# 3. 按照 Tag 批量删除符合条件的任务
cron_del_by_tag() {
    local target_tag="$1"
    local path_opt="$(_get_uci_path_opt)"
    local deleted_count=0

    if [ -z "$target_tag" ]; then
        echo -e "\n ❌ 参数缺失！用法: cron_del_by_tag <tag>"
        return 1
    fi

    for section in $(uci $path_opt -q show "$_UCI_CRON_FILE" | grep "=task" | awk -F'.' '{print $2}' | awk -F'=' '{print $1}'); do
        local tag=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${section}.tag")
        if [ "$tag" = "$target_tag" ]; then
            uci $path_opt delete "${_UCI_CRON_FILE}.${section}" 2>/dev/null
            deleted_count=$((deleted_count + 1))
        fi
    done

    if [ "$deleted_count" -gt 0 ]; then
        uci $path_opt commit "$_UCI_CRON_FILE"
        cron_sync_all
        echo -e "\n ✅ 已清除 TAG 为 [${target_tag}] 的 $deleted_count 个定时任务"
        return 0
    else
        echo -e "\n ⚠️ 未找到 TAG 为 [${target_tag}] 的任务"
        return 1
    fi
}

cron_menu() {
    while true; do
        clear
        main_line
        print_center "⏰ ${C_BOLD}定时任务管理${C_RESET}" 7
        sub_line

        local path_opt="$(_get_uci_path_opt)"
        local count=0
        local id_list=""

        # 遍历生成编号与 ID 映射
        for section in $(uci $path_opt -q show "$_UCI_CRON_FILE" | grep "=task" | awk -F'.' '{print $2}' | awk -F'=' '{print $1}'); do
            count=$((count + 1))
            local enabled=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${section}.enabled")
            local remark=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${section}.remark")
            local tag=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${section}.tag")

            # 状态图标
            local status_icon="🔴"
            [ "$enabled" = "1" ] && status_icon="🟢"

            # 优先展示备注说明，无备注时展示 Tag 或 ID
            local desc="${remark:-${tag:-$section}}"

            # 列表序号进行两位数字补零
            local formatted_count="$(printf '%02d' "$count")"
            echo -e " ${C_GREEN}${formatted_count})${C_RESET} ${status_icon} ${section} ${C_DIM}(${desc})${C_RESET}"

            # 将序号映射保存到变量字符串中（保持原始 count 纯数字映射）
            id_list="${id_list}${count}:${section} "
        done

        if [ "$count" -eq 0 ]; then
            print_center "${C_NOR_YELLOW}🤹 当前没有定时任务${C_RESET}" 9
        fi

        sub_line
        echo -e " ${C_GREEN}AA)${C_RESET} ➕ 添加新任务"
        echo -e " ${C_GRAY}00)${C_RESET} 🔙 返回"
        main_line

        # 提示文本范围对齐补零格式
        if [ "$count" -gt 0 ]; then
            printf " 👉 请选择 [0-$count/A]: "
        else
            printf " 👉 请选择 [0/A]: "
        fi
        read -r choice

        # 处理 A / AA / a / aa 输入
        case "$choice" in
            *[!aA]*|"")
                :
                ;;
            *)
                _cron_menu_add
                mikit_pause
                continue
                ;;
        esac

        case "$choice" in
            0|00) break ;;
            *)
                # ⚡ 纯字符串处理：剥离前导零，绝对避免 Shell 算术语法错误
                local clean_choice="$choice"
                case "$clean_choice" in
                    0*) clean_choice="${clean_choice#0}" ;; # 去除开头的 0 (如 01 -> 1)
                esac

                # 根据输入的数字匹配对应的 task_id
                local target_id=""
                for item in $id_list; do
                    local idx="${item%%:*}"
                    local tid="${item#*:}"
                    if [ "$clean_choice" = "$idx" ]; then
                        target_id="$tid"
                        break
                    fi
                done

                if [ -n "$target_id" ]; then
                    _cron_menu_detail "$target_id"
                else
                    echo -e "\n ❌ 无效输入！"
                    mikit_pause
                fi
                ;;
        esac
    done
}

_cron_menu_detail() {
    local t_id="$1"
    local path_opt="$(_get_uci_path_opt)"

    while true; do
        clear
        main_line
        print_center "📌 任务详情: [${t_id}]" 5
        sub_line

        local tag=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${t_id}.tag")
        local enabled=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${t_id}.enabled")
        local expr=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${t_id}.cron_expr")
        local cmd=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${t_id}.command")
        local remark=$(uci $path_opt -q get "${_UCI_CRON_FILE}.${t_id}.remark")

        echo -e "  🏷️ Tag       : ${tag:-N/A}"
        echo -e "  🚀 Enabled   : $([ "$enabled" = "1" ] && echo -e "${C_GREEN}▶${C_RESET}" || echo -e "${C_RED}■${C_RESET}")"
        echo -e "  ⏱️ cron Expr : ${expr}"
        echo -e "  ⚙️ Cron Cmd  : ${cmd}"
        echo -e "  📝 remark    : ${remark:-无}"
        sub_line
        echo -e " ${C_GREEN}1)${C_RESET} ✏️  修改此任务"
        echo -e " ${C_GREEN}2)${C_RESET} 🗑️  删除此任务"
        echo -e " ${C_GRAY}0)${C_RESET} 🔙  返回"
        main_line
        printf "请选择操作 [0-2]: "
        read -r sub_choice

        case "$sub_choice" in
            1)
                printf " 🔹 标识 Tag [%s]: " "${tag:-无}"
                read -r new_tag
                printf " 🔹 是否启用 [1:启用 / 0:禁用] [%s]: " "${enabled}"
                read -r new_enabled
                printf " 🔹 Cron 表达式 [%s]: " "${expr}"
                read -r new_expr
                printf " 🔹 执行命令 [%s]: " "${cmd}"
                read -r new_cmd
                printf " 🔹 备注说明 [%s]: " "${remark:-无}"
                read -r new_remark

                cron_set_task "$t_id" \
                              "${new_tag:-$tag}" \
                              "${new_enabled:-$enabled}" \
                              "${new_expr:-$expr}" \
                              "${new_cmd:-$cmd}" \
                              "${new_remark:-$remark}"
                ;;
            2)
                printf " ⚠️ 确定要删除任务 [%s] 吗？(y/N): " "$t_id"
                read -r confirm
                case "$confirm" in
                    [yY][eE][sS]|[yY])
                        cron_del_by_id "$t_id"
                        return 0
                        ;;
                    *) echo -e "\n ❌ 操作已取消" ;;
                esac
                ;;
            0) return 0 ;;
            *) echo -e "\n ❌ 无效选项！" ;;
        esac
    done
}

_cron_menu_add() {
    echo ""
    echo "--- ➕ 添加定时任务 ---"
    printf " 🔹 任务 ID (纯字母/数字/下划线): "
    read -r t_id
    [ -z "$t_id" ] && { echo -e "\n ❌ ID 不能为空！"; return 1; }

    if cron_has_task "$t_id"; then
        echo -e "\n ❌ 该任务 ID 已存在！"
        return 1
    fi

    printf " 🔹 标识 Tag (可选): "
    read -r t_tag
    printf " 🔹 是否启用 [1:启用 / 0:禁用] (默认 1): "
    read -r t_enabled
    t_enabled="${t_enabled:-1}"

    printf " 🔹 Cron 表达式 (如 0 3 * * *): "
    read -r t_expr
    printf " 🔹 执行命令: "
    read -r t_cmd
    printf " 🔹 备注说明 (可选): "
    read -r t_remark

    cron_set_task "$t_id" "$t_tag" "$t_enabled" "$t_expr" "$t_cmd" "$t_remark"

}